<?php $__env->startSection('Title','EDGE-Teacher Subjects'); ?>

<?php $__env->startSection('content'); ?>
<div class="form-container">
    <form action="<?php echo e(route('post_teacher_subject')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="">Select a Teacher</label>
        <select name="teacher_id" id="" required>
            <option value="">Select a Teacher</option>
            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <!-- <input type="text" name="student_id" placeholder="Enter Roll"><br><br> -->
        <label for="">Select a Subject</label>
        <select name="subject_id" id="" required>
            <option value="">Select a Subject</option>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        
        <input type="submit" value="Save">
    </form>
</div>
    <br>
    <a style="float: right; background-color: rgb(126, 3, 207); color:white; text-decoration:none; padding:5px" href="<?php echo e(url('/teacher_subject_pdf')); ?>">     <i class="fa fa-print"></i> Print
    </a>
    <?php if($teacher_subjects->isEmpty()): ?>
        <p>No data available</p>
    <?php else: ?>
    <table class="styled-table">
        <thead>
        <tr>
            <th>SL</th>
            <th>Name</th>
            <th>Subject</th>
            <th>Academic Session</th>
            <th>Added At</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $serial = ($teacher_subjects->currentPage() - 1) *$teacher_subjects->perPage();
    ?>
        <?php $__currentLoopData = $teacher_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$teacher_subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($serial+ $key + 1); ?></td>
                <td><?php echo e($teacher_subject->teacher->name); ?></td>
                <td><?php echo e($teacher_subject->subject->title); ?></td>
                <td><?php echo e($teacher_subject->subject->sessions->session); ?></td>
                <td><?php echo e($teacher_subject->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    <?php echo e($teacher_subjects->links('vendor.pagination.custom')); ?>


    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/teacher_subjects.blade.php ENDPATH**/ ?>