<?php $__env->startSection('Title','EDGE-Department'); ?>

<?php $__env->startSection('content'); ?>
<div class="form-container">
    <form action="<?php echo e(route('department_post')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="">Title</label>
        <input type="text" name="title" placeholder="Enter a department" required><br><br>
        <input type="submit" value="Save">
    </form>
</div>
    <br>
    <a style="float: right; background-color: rgb(126, 3, 207); color:white; text-decoration:none; padding:5px" href="<?php echo e(url('/department_pdf')); ?>">     <i class="fa fa-print"></i> Print
    </a>

    <?php if($departments->isEmpty()): ?>
        <p>No data available</p>
    <?php else: ?>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>SL</th>
                    <th>Title</th>
                    <th>Added at</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $serial = ($departments->currentPage() - 1) *$departments->perPage();
                ?>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($serial+ $key + 1); ?></td>
                    <td><?php echo e($department->title); ?></td>
                    <td><?php echo e($department->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
        <?php echo e($departments->links('vendor.pagination.custom')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/department.blade.php ENDPATH**/ ?>