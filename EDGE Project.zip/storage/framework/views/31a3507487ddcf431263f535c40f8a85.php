<?php $__env->startSection('Title','EDGE-Home'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Admin Dashboard</h1>
    <div class="dashboard">
        <div class="box">
            <h2>Students</h2>
            <p><?php echo e($students); ?></p>
        </div>
        <div class="box">
            <h2>Teachers</h2>
            <p><?php echo e($teachers); ?></p>
        </div>
        <div class="box">
            <h2>Subjects</h2>
            <p><?php echo e($subjects); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/index.blade.php ENDPATH**/ ?>