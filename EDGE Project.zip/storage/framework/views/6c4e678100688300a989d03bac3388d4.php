this is a test

<?php echo e($title); ?>

<?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/pdf.blade.php ENDPATH**/ ?>