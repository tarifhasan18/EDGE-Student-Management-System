<?php $__env->startSection('Title','EDGE-Student'); ?>


<?php $__env->startSection('content'); ?>

<div class="form-container">
    <form action="<?php echo e(route('students_post')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="">Name</label>
        <input type="text" name="name" placeholder="Enter name" required><br><br>
        <label for="">Address</label>
        <input type="text" name="address" placeholder="Enter address" required><br><br>
        <label for="">Roll</label>
        <input type="text" name="roll" placeholder="Enter roll" required><br><br>
        <label for="">Mobile</label>
        <input type="text" name="mobile" placeholder="Enter mobile" required><br><br>
        <label for="">Blood Group</label>
        <input type="text" name="blood_group" placeholder="Enter blood grouo" required><br><br>
        <label for="">Select a Department</label>
        <select name="department_id" id="" required>
            <option value="">Select a Department</option>
            <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($department->id); ?>"><?php echo e($department->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>
        <input type="submit" value="Insert">
    </form>
</div>
<br>
<a style="float: right; background-color: rgb(126, 3, 207); color:white; text-decoration:none; padding:5px" href="<?php echo e(url('/student_list_pdf')); ?>">     <i class="fa fa-print"></i> Print
</a>
<?php if($students->isEmpty()): ?>
    <p>No data available</p>
<?php else: ?>
<table class="styled-table">
    <thead>
    <tr>
        <th>SL</th>
        <th>Name</th>
        <th>Address</th>
        <th>Roll</th>
        <th>Mobile</th>
        <th>Blood Group</th>
        <th>Department</th>
        <th>Added at</th>
    </tr>
</thead>
<tbody>
    <?php
        $serial = ($students->currentPage() - 1) *$students->perPage();
    ?>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            
            <td><?php echo e($serial+ $key + 1); ?></td>
            <td><?php echo e($student->name); ?></td>
            <td><?php echo e($student->address); ?></td>
            <td><?php echo e($student->roll); ?></td>
            <td><?php echo e($student->mobile); ?></td>
            <td><?php echo e($student->blood_group); ?></td>
            <td><?php echo e($student->department->title); ?></td>
            <td><?php echo e($student->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php echo e($students->links('vendor.pagination.custom')); ?>


<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/student.blade.php ENDPATH**/ ?>