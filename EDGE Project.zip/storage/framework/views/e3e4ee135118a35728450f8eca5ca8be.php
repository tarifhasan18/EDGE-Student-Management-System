<?php $__env->startSection('Title','EDGE-Student Registrations'); ?>

<?php $__env->startSection('content'); ?>
<div class="form-container">
    <form action="<?php echo e(route('post_student_subject')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="">Roll</label>
        <select name="student_id" id="">
            <option value="">Select a Student</option>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($students->id); ?>"><?php echo e($students->roll); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <label for="">Select Subject</label>
        <select name="subject_id" id="">
            <option value="">Select a Subject</option>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <input type="submit" value="Save">
    </form>
</div><br>
<a style="float: right; background-color: rgb(126, 3, 207); color:white; text-decoration:none; padding:5px" href="<?php echo e(url('/student_subject_pdf')); ?>">     <i class="fa fa-print"></i> Print
</a>
    <?php if($students_subjects->isEmpty()): ?>
        <p>No data available</p>
    <?php else: ?>
    <table class="styled-table">
        <thead>
            <tr>
                <th>SL</th>
                <th>Roll</th>
                <th>Subject</th>
                <th>Academic Session</th>
                <th>Added At</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $serial = ($students_subjects->currentPage() - 1) *$students_subjects->perPage();
        ?>
            <?php $__currentLoopData = $students_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $students_subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($serial+ $key + 1); ?></td>
                    <td><?php echo e($students_subject->student->roll); ?></td>
                    <td><?php echo e($students_subject->subject->title); ?></td>
                    <td><?php echo e($students_subject->subject->sessions->session); ?></td>
                    <td><?php echo e($students_subject->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($students_subjects->links('vendor.pagination.custom')); ?>


    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/student_subject.blade.php ENDPATH**/ ?>