<?php $__env->startSection('Title','EDGE-Teacher'); ?>

<?php $__env->startSection('content'); ?>
<div class="form-container">
<form action="<?php echo e(route('teachers_post')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="">Name</label>
    <input type="text" name="name" placeholder="Teacher Name" required><br><br>

    <label for="">Phone</label>
    <input type="text" name="phone" placeholder="Phone Number" required><br><br>

    <label for="">Address</label>
    <input type="text" name="address" placeholder="Teacher Address" required><br><br>
    <label for="">Select Department</label>
    <select name="department_id" id="">
        <option value="">Select a Department</option>
    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($department->id); ?>"><?php echo e($department->title); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select><br><br>
    <input type="submit" value="Save">
</form>
</div><br>
<a style="float: right; background-color: rgb(126, 3, 207); color:white; text-decoration:none; padding:5px" href="<?php echo e(url('/teachers_pdf')); ?>">     <i class="fa fa-print"></i> Print
</a>
<?php if($teachers->isEmpty()): ?>
    <p>No teachers available.</p>
<?php else: ?>
    <table class="styled-table">
        <thead>
        <tr>
            <th>SL</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Department</th>
            <th>Added At</th>
        </tr>
        </thead>
        <tbody>
            <?php
                $serial = ($teachers->currentPage() - 1) *$teachers->perPage();
            ?>
        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($serial+ $key + 1); ?></td>
                <td><?php echo e($teacher->name); ?></td>
                <td><?php echo e($teacher->phone); ?></td>
                <td><?php echo e($teacher->address); ?></td>
                <td><?php echo e($teacher->department->title); ?></td>
                <td><?php echo e($teacher->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    <?php echo e($teachers->links('vendor.pagination.custom')); ?>


<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/teachers.blade.php ENDPATH**/ ?>