<style>
    <?php echo e($css); ?>

</style>
<h1 style="text-align: center">Student List</h1>
<table>
    <tr>
        <th>SL</th>
        <th>Name</th>
        <th>ID</th>
        <th>Address</th>
        <th>Mobile</th>
        <th>Blood Group</th>
        <th>Department</th>
        <th>Added at</th>
    </tr>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($student->name); ?></td>
            <td><?php echo e($student->id); ?></td>
            <td><?php echo e($student->address); ?></td>
            <td><?php echo e($student->mobile); ?></td>
            <td><?php echo e($student->blood_group); ?></td>
            <td><?php echo e($student->department->title); ?></td>
            <td><?php echo e($student->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/pdf/student_list.blade.php ENDPATH**/ ?>