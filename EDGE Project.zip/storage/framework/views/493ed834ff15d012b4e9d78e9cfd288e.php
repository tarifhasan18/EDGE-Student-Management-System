<?php $__env->startSection('Title','EDGE-Subjects'); ?>

<?php $__env->startSection('content'); ?>
<div class="form-container">
    <form action="<?php echo e(route('subjects_post')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="">Title</label>
        <input type="text" name="title" placeholder="Subject Title" required><br><br>

        <label for="">Credit</label>
        <input type="text" name="credit" placeholder="Enter Credit" required><br><br>

        <label for="">Select Department</label>
        <select name="department_id" id="">
            <option value="">Select a Department</option>
        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($department->id); ?>"><?php echo e($department->title); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <label for="">Select Session</label>
        <select name="session_id" id="">
            <option value="">Select a Session</option>
        <?php $__currentLoopData = $academic_sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($session->id); ?>"><?php echo e($session->session); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <input type="submit" value="Save">
    </form>
</div>
    <br>
    <a style="float: right; background-color: rgb(126, 3, 207); color:white; text-decoration:none; padding:5px" href="<?php echo e(url('/subject_pdf')); ?>">     <i class="fa fa-print"></i> Print
    </a>
    <?php if($subjects->isEmpty()): ?>
        <p>No data available</p>
    <?php else: ?>
    <table class="styled-table">
        <thead>
            <tr>
                <th>SL</th>
                <th>Title</th>
                <th>Credit</th>
                <th>Department</th>
                <th>Session</th>
                <th>Added At</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $serial = ($subjects->currentPage() - 1) *$subjects->perPage();
            ?>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($serial+ $key + 1); ?></td>
                <td><?php echo e($subject->title); ?></td>
                <td><?php echo e($subject->credit); ?></td>
                <td><?php echo e($subject->department->title); ?></td>
                <td><?php echo e($subject->sessions->session); ?></td>
                <td><?php echo e($subject->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
    <?php echo e($subjects->links('vendor.pagination.custom')); ?>


    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/subject.blade.php ENDPATH**/ ?>