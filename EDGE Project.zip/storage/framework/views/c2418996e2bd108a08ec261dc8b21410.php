<div class="sidebar">
    <div class="profile">
        <img src="<?php echo e(asset('img/KU.png')); ?>" alt="Logo">
        <h2>EDGE</h2>
    </div>
    <ul class="menu">
        
        <li><a href="<?php echo e(url('/')); ?>"><i style="color: yellow; margin: 5px" class="fa-solid fa-house"></i>Home</a></li>
        <li><a href="<?php echo e(url('/academic_session')); ?>"><i style="color: yellow; margin: 5px" class="fa-solid fa-calendar"></i> Academic Session</a></li>
        <li><a href="<?php echo e(url('/department')); ?>"><i style="color: yellow; margin: 5px" class="fa-solid fa-building-columns"></i> Department</a></li>
        <li><a href="<?php echo e(url('/subjects')); ?>"><i style="color: yellow; margin: 5px" class="fa-solid fa-book-open"></i> Subjects</a></li>
        <li><a href="<?php echo e(url('/students')); ?>"><i style="color: yellow; margin: 5px" class="fa-solid fa-user-graduate"></i> Students</a></li>
        <li><a href="<?php echo e(url('/student_subject')); ?>"><i style="color: yellow; margin: 5px"  class="fa-solid fa-user-plus"></i> Student Registrations</a></li>
        <li><a href="<?php echo e(url('/teachers')); ?>"><i style="color: yellow; margin: 5px"   class="fa-solid fa-chalkboard-teacher"></i>Teachers</a></li>
        <li><a href="<?php echo e(url('/teacher_subjects')); ?>"><i style="color: yellow; margin: 5px"   class="fa-solid fa-chalkboard-teacher"></i>Teacher Subjects</a></li>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/sidebar.blade.php ENDPATH**/ ?>