
<style>
    <?php echo e($css); ?>

</style>
<h1 style="text-align: center">Student-Subject List</h1>
<table>
    <tr>
        <th>SL</th>
        <th>Roll</th>
        <th>Name</th>
        <th>Department</th>
        <th>Subject</th>
        <th>Session</th>
        <th>Added at</th>
    </tr>
    <?php $__currentLoopData = $student_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($student_subject->student->roll); ?></td>
            <td><?php echo e($student_subject->student->name); ?></td>
            <td><?php echo e($student_subject->student->department->title); ?></td>
            <td><?php echo e($student_subject->subject->title); ?></td>
            <td><?php echo e($student_subject->subject->sessions->session); ?></td>
            <td><?php echo e($student_subject->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/pdf/student_subject.blade.php ENDPATH**/ ?>