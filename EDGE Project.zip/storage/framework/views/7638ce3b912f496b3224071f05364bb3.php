<style>
    <?php echo e($css); ?>

</style>
<h1 style="text-align: center">Teacher List</h1>
<table>
    <tr>
        <th>SL</th>
        <th>Name</th>
        <th>Department</th>
        <th>Subject</th>
        <th>Session</th>
        <th>Added at</th>
    </tr>
    <?php $__currentLoopData = $teacher_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher_subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($teacher_subject->teacher->name); ?></td>
            <td><?php echo e($teacher_subject->teacher->department->title); ?></td>
            <td><?php echo e($teacher_subject->subject->title); ?></td>
            <td><?php echo e($teacher_subject->subject->sessions->session); ?></td>
            <td><?php echo e($teacher_subject->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/pdf/teacher_subject.blade.php ENDPATH**/ ?>