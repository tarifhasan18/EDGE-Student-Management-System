<style>
    <?php echo e($css); ?>

</style>
<h1 style="text-align: center">Session List</h1>
<table>
    <tr>
        <th>SL</th>
        <th>Academic Session</th>
        <th>Added at</th>
    </tr>
    <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($session->session); ?></td>
            <td><?php echo e($session->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/pdf/session_list.blade.php ENDPATH**/ ?>