<?php $__env->startSection('Title','EDGE-Academic Session'); ?>

<?php $__env->startSection('content'); ?>
<div class="form-container">
  <form action="<?php echo e(route('session_post')); ?>" method="POST">
    <?php echo csrf_field(); ?>
        <label for="">Academic Session</label>
        <input type="text" name="session" placeholder="Enter Academic Session" required><br><br>
        <input type="submit" value="Save">
  </form>
</div>
  <br>
  <a style="float: right; background-color: rgb(126, 3, 207); color:white; text-decoration:none; padding:5px" href="<?php echo e(url('/sessions_pdf')); ?>">     <i class="fa fa-print"></i> Print
  </a>
  <?php if($academic_sessions->isEmpty()): ?>
    <p>No Data available</p>
  <?php else: ?>
  <table class="styled-table">
    <thead>
    <tr>
        <th>SL</th>
        <th>Academic Session</th>
        <th>Added at</th>
    </tr>
    </thead>
    <tbody>
        <?php
            $serial = ($academic_sessions->currentPage() - 1) *$academic_sessions->perPage();
        ?>
    <?php $__currentLoopData = $academic_sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($serial+ $key + 1); ?></td>
            <td><?php echo e($session->session); ?></td>
            <td><?php echo e($session->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($academic_sessions->links('vendor.pagination.custom')); ?>

  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EDGE Project\resources\views/academic_session.blade.php ENDPATH**/ ?>